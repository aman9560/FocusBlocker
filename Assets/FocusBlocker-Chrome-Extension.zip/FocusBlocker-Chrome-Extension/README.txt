FOCUS BLOCKER CHROME EXTENSION — MANUAL INSTALL REQUIRED

Chrome does not install this extension automatically with the Focus Blocker app.

1. Keep this folder at a permanent location.
2. Open chrome://extensions in Chrome.
3. Enable Developer mode.
4. Choose Load unpacked and select this folder.
5. Install the native messaging host using the setup steps at:
   https://github.com/aman9560/FocusBlocker/blob/main/Assets/CHROME-EXTENSION-INSTALL.md

This extension is not currently listed in the Chrome Web Store.
